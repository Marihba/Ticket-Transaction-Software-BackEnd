To compile in Linux:
> javac *java

To run:
> java Controller